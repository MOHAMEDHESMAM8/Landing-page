# Landing Page 

Udacity Professional Front-End Web Development Course


## What the project does?
Using Javascript to create dynamic landing page.


## Programing Language
1. HTML
2. CSS
3. JavaScript

## How to use this project ?
1. open git then write 
> git clone https://github.com/MOHAMEDHESMAM8Landing-page.git

2. open the **index** file in any browser

